/**
 * Data Table
 */
import React from 'react';
// MUI data table 
import MUIDataTable from "mui-datatables";
import IconButton from '@material-ui/core/IconButton';
//axios call
import axios from 'axios';
import {baseURL} from '../../../services/Config.js';

// MUI Theme - added to customize cell Theme  
import { createMuiTheme, MuiThemeProvider } from '@material-ui/core/styles';

// page title bar
import PageTitleBar from 'Components/PageTitleBar/PageTitleBar';

// rct card box
import { RctCard, RctCardContent } from 'Components/RctCard'; 

// intl messages
import IntlMessages from 'Util/IntlMessages';

//Reloadable card
import {WatchesWidget} from "Components/Widgets";
	
class inductStatus extends React.Component {
	
	 constructor(props) {
    super(props);
	this.state = {  data: [],
					inductsVal: [],
					isLoading:true
				 };
	}
		
      
	/*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.onReload();
	}


	linkState = this.props.location.state === undefined ? '' : this.props.location.state.nextLink

	onReload = () => {
		axios.get(baseURL+'inductionstatus/'+ localStorage.getItem("user_id") )
			.then(res => {
				console.log(res.data); 
				let inductsVal = res.data.map(list => list.inducts_per_hour);

				this.setState({ data: res.data,
								inductsVal: inductsVal,
								isLoading:false}); 
			}).catch(function (error) {
				console.log(error);
		});
	}

	  getMuiTheme = () => createMuiTheme({
	  overrides: {
		MUIDataTableHeadCell : {
			root: {			
				padding: '4px 20px 4px 20px',	
			    fontSize: '13px',
				color: 'black',
				width:120,
				whiteSpace: 'nowrap'
				
		  }}, 
	   
		MUIDataTableBodyCell: {
		  root: {			
			  padding: '4px 20px 4px 20px',
			  fontSize: '12px',
			  //to add color to the 1st column 
			  '&:nth-child(2)': {	
				backgroundColor: '#CD5C5C',
				width: 100
			  },
			   //to add text-color to the 5th column 
			    '&:nth-child(10)': {			  
				color: '#CD5C5C',					  			
			  },
			  '&:nth-child(20)': {			  
				width: '130px',
				whiteSpace: 'nowrap'

			  }
		  }
		},
		// to remove toolBar
		MUIDataTableToolbar: {
			     root: {
			        display: 'none'
			    }
			} 
	  }
	})
	
	render() {
	    const rows = this.state.data; 
				console.log(this.state.inductsVal);				

		const columns = ["", "Runtime", "Total Inducts", "Induct/hour", "Utilization", "Peak Rate", "Peak Rate", "Average Rate", "Current user", "Last Scan"];
		
		const options = {
			filterType: 'dropdown',
			responsive: 'stacked',
			selectableRows: false // to remove the checkbox
		};
		const { match } = this.props;

		return (
			<div className="data-table-wrapper">
				<PageTitleBar 
					url="/app/dashboard/sorterDetails" 
					urlState={this.linkState}
					title={<IntlMessages id="sidebar.inductStatusTable" />} 
					match={match} 
				/>
				<RctCard>
		        <RctCardContent>
		        	<div className="contextual-link float-left chute-sub-header">
		        		Induction Status
					</div>
					<div className="contextual-link float-right ">
						<i className="refresh-button" onClick={() => this.onReload()}><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 6v3l4-4-4-4v3c-4.42 0-8 3.58-8 8 0 1.57.46 3.03 1.24 4.26L6.7 14.8c-.45-.83-.7-1.79-.7-2.8 0-3.31 2.69-6 6-6zm6.76 1.74L17.3 9.2c.44.84.7 1.79.7 2.8 0 3.31-2.69 6-6 6v-3l-4 4 4 4v-3c4.42 0 8-3.58 8-8 0-1.57-.46-3.03-1.24-4.26z"/></svg></i>
						
						
					</div> 

					<MuiThemeProvider theme={this.getMuiTheme()}>
					<MUIDataTable
						data={rows.map(item => {
								console.log(item.inducts_per_hour);	
									
								return [
									"Station A",
									item.runtime,
									item.total_inducts,
									item.inducts_per_hour,
									item.utilization,
									item.peak_rate,
									item.min_rate,
									item.avg_rate,
									item.current_usr,
									item.last_scan
								]
								
							})}
						columns={columns}
						options={options}
					/>
					</MuiThemeProvider>
				</RctCardContent>
			</RctCard >
		</div>
		);
	}
}

export default inductStatus;
