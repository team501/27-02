/**
 * Ecommerce Dashboard
 */

import React, { Component } from 'react';

//Reloadable card
import {InductsForTheDayWidget,
		WaveStatusWidget,
		InductsForTheLastHourWidget,
		SortsForTheDayWidget,
		SortsForTheLastHourWidget,
		SortersWidget} from "Components/Widgets";

// intl messages
import IntlMessages from 'Util/IntlMessages';

// page title bar
import PageTitleBar from 'Components/PageTitleBar/PageTitleBar';


export default class EcommerceDashboard extends Component {

	constructor(props) {
		super(props);
		this.state = { currentTime: {} };
	}
	
	//Starting cyclic-refresh. 
	async componentDidMount() {		
	    this.intervalID = setInterval( () => this.timeGenrator(), localStorage.getItem("refreshInterval") );
	}
	
	/*Refresh callback function,
	 *responsible for generating time as props for child elements.*/
	async timeGenrator() {
		console.log(".....................................");
		this.setState({ currentTime: new Date().getTime() });
	}
	
	//Clearing previous interval on component unmount.
	componentWillUnmount() {
	    clearInterval(this.intervalID);
	}

   render() {
	  const { match } = this.props;
      return (
         <div className="ecom-dashboard-wrapper">
            <PageTitleBar title={<IntlMessages id="widgets.unitsorterdashboard" />} arrowRequired={false} match={match} />
            <div className="row row-no-margin">
            	<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 col-class-left">
					{/*Passing sorter routes for sorter id and current time.*/}
					<InductsForTheDayWidget currentTime={this.state.currentTime} sorterRoute="" />
					<InductsForTheLastHourWidget currentTime={this.state.currentTime} sorterRoute="" />
					<SortsForTheDayWidget currentTime={this.state.currentTime} sorterRoute="" />
					<SortsForTheLastHourWidget currentTime={this.state.currentTime} sorterRoute="" />
            	</div>
            	<div className="col-sm-8 col-md-8 col-lg-8 col-xl-8 col-class-right">
					<WaveStatusWidget currentTime={this.state.currentTime} />
					<SortersWidget currentTime={this.state.currentTime} />
            	</div>
            </div>
         </div>
      )
   }
}
