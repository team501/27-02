export const baseURL = "http://localhost:9080/";
export const graphQlURL = "http://localhost:8080/graphql";
export const wCSURL = "http://localhost:8082/api/login";
