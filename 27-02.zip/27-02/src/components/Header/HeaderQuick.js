/**
 * User Block Component
 */
import React, { Component } from 'react';
import { UncontrolledDropdown, Dropdown, DropdownToggle, DropdownMenu } from 'reactstrap';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
//import { Badge } from 'reactstrap';
import { NotificationManager } from 'react-notifications';
import Tooltip from '@material-ui/core/Tooltip';
import { Scrollbars } from 'react-custom-scrollbars';



import Settings from '../../assets/img/Setting_icon.png';
import User from '../../assets/img/User_icon.png';
import Bell from '../../assets/img/Bell_icon.png';
import Menu from '../../assets/img/menu_icon.jpg';
import Close from '../../assets/img/close.jpg';
import Dashboard from '../../assets/img/dashboard_icon.jpg';
import BalanceLbr from '../../assets/img/balanceLabor_icon.jpg';
import Equipment from '../../assets/img/equipment_icon.jpg';
import ManageInvt from '../../assets/img/manageInventory_icon.jpg';
import ManageOrdr from '../../assets/img/manageOrder_icon.jpg';
import Reports from '../../assets/img/reports_icon.jpg';
import WorkMonitoring from '../../assets/img/workMonitoring_icon.jpg';
import Exception from '../../assets/img/exception_icon.jpg';
import  Access  from '../../constants/AccessConfig';

// components
//import SupportPage from '../Support/Support';

// redux action
import { logoutUserFromFirebase } from 'Actions';

// intl messages
import IntlMessages from 'Util/IntlMessages';
const userName = localStorage.getItem("user_id");

class HeaderQuick extends Component {

	constructor(props) {
		super(props);
		this.state = { assignedPermissions: JSON.parse(localStorage.getItem("assignedPermissions")),
					   statusMessage: localStorage.getItem("statusMessage"),
					   userDropdownMenu: false,
					   isSupportModal: false,
		};
	}

	componentDidMount() {
		this.setState({ assignedPermissions: JSON.parse(localStorage.getItem("assignedPermissions")),
					    statusMessage: localStorage.getItem("statusMessage")
		});
		console.log(this.state.assignedPermissions);
	}
	
	/**
	 * Logout User
	 */
	logoutUser() {
		this.props.logoutUserFromFirebase();
	}

	/**
	 * Toggle User Dropdown Menu
	 */
	toggleUserDropdownMenu() {
		this.setState({ userDropdownMenu: !this.state.userDropdownMenu });
	}


	render() {
		return (
		<UncontrolledDropdown nav className="list-inline-item quciklink-dropdown tour-step-1 menu-icon">
                <Dropdown
                    isOpen={this.state.userDropdownMenu}
                    toggle={() => this.toggleUserDropdownMenu()}
                    className="rct-dropdown"
                >
                    <DropdownToggle nav className="header-icon p-0 hambergerIcon">
			<Tooltip title="Quick Links" placement="bottom">
				<i className="zmdi zmdi-storage"></i>
			</Tooltip>
		</DropdownToggle>
                    <DropdownMenu className="drop-downLayout-landing">
					<Scrollbars className="rct-scroll" autoHeight autoHeightMin={100} autoHeightMax={350}>
					<div className="dropdown-content">
					<div className="dropdown-top d-flex justify-content-between rounded-top bg-primary">
						<span className="text-white font-weight-bold">Quick Links</span>
						
					</div>
					{ this.state.assignedPermissions.length > 0 && 
						(
                        <ul className="list-unstyled mb-0 dropdown-list">
						
                        { this.state.assignedPermissions.indexOf(Access.Dashboard) > -1 && (
						  <li>
							<Link to={`#`}>
							<img src={Dashboard} className="image"/>
								<IntlMessages id="widgets.dashboard" />
							</Link>	
						  </li>
                        ) }
                        
                        { this.state.assignedPermissions.indexOf(Access.BalanceLabour) > -1 && (
						  <li>
							<Link to={`#`}>
							<img src={BalanceLbr} className="image"/>
								<IntlMessages id="widgets.BalanceLabour" />
							</Link>
							  </li>
                        ) }
						
                        { this.state.assignedPermissions.indexOf(Access.WorkMonitoring) > -1 && (
						<li>
							<Link to={`#`}>
							<img src={WorkMonitoring} className="image"/>
								<IntlMessages id="widgets.WorkMonitoring" />
							</Link>
						</li>
                        ) }
                        
                        { this.state.assignedPermissions.indexOf(Access.Exceptions) > -1 && (
						<li>
							<Link to={`#`}>
							<img src={Exception} className="image"/>
								<IntlMessages id="widgets.Exceptions" />
							</Link>
						</li>
                        ) }
                        
                        { this.state.assignedPermissions.indexOf(Access.ManageOrder) > -1 && (
						<li>
							<Link to={`#`}>
							<img src={ManageOrdr} className="image"/>
								<IntlMessages id="widgets.ManageOrderWaves" />
							</Link>
						</li>
                        ) }
                        
                        { this.state.assignedPermissions.indexOf(Access.ManageEquipment) > -1 && (
						<li>
							<Link to={`/app/dashboard/manageEquipment`}>
							<img src={Equipment} className="image"/>
								<IntlMessages id="widgets.ManageEquipment" />
							</Link>
						</li>
                        ) }
                        
                        { this.state.assignedPermissions.indexOf(Access.ManageInventory) > -1 && (
						<li>
							<Link to={`#`}>
							<img src={ManageInvt} className="image"/>
								<IntlMessages id="widgets.ManageInventory" />
									</Link>
						</li>
                        ) }
                        
                        { this.state.assignedPermissions.indexOf(Access.Report) > -1 && (
						<li>
							<Link to={`#`}>
							<img src={Reports} className="image"/>
								<IntlMessages id="widgets.Report" />
							</Link>
						</li>
                        ) }
					</ul>
					)}
					</div>
					</Scrollbars>
                    </DropdownMenu>
                </Dropdown>
				</UncontrolledDropdown>
		);
	}
}

// map state to props
const mapStateToProps = ({ settings }) => {
	return settings;
}

export default connect(mapStateToProps, {
	logoutUserFromFirebase
})(HeaderQuick);
