/**
 * InductsForTheDay
 */
import React, { Component } from 'react';
import { connect } from 'react-redux'; // to connect the component as part of mapStateToProps
import { withRouter } from 'react-router-dom'; //will pass updated props to the wrapped component 

import AppConfig from 'Constants/AppConfig';

//json
import json from '../../assets/data/jsonDataConfig/UnitSorterMainDashboard/inductsForTheDayJson';

// api
import api from 'Api';
import CountUp from 'react-countup';
//chart
import TinyAreaChart from 'Components/Charts/TinyAreaChart';
//chart config
import ChartConfig from 'Constants/chart-config';

// helpers
import { hexToRgbA } from 'Helpers/helpers';
import {baseURL, graphQlURL} from '../../services/Config.js';
import CircularProgressbar from 'react-circular-progressbar';
//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';

import NumberClass from 'Util/NumberClass';
var dateFormat = require('dateformat'); 

class InductsForTheDay extends Component {

	state = {
			data: [],
			label: null,
			graphData: null,
			currentValue: 0
	}

	/*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.getRecentOrders();
	}

	//Comparing props and triggering refresh 
	componentDidUpdate(prevProps) {
		// Typical usage (don't forget to compare props):
		if (this.props.currentTime !== prevProps.currentTime) {
			this.getRecentOrders();
		}
	}

	// recent orders
	getRecentOrders() {
		let currentTemp = 0;
		let query = `query GetInductsForLastHour($key: String!, $startTime: String!) {
						getInductsForLastHour(key: $key, startTime: $startTime) { duration measure condition totalInducts }
					}`;
		let key = "USSStatistics";
		let currentTime = dateFormat(new Date(), "mm-dd-yyyy H:MM");
		console.log("============================================")
		console.log(currentTime);
		console.log("============================================")
		let startTime = dateFormat(new Date(), "mm-dd-yyyy H:MM");
		//let startTime = '02-18-2019 15:59';
		//let query = '{getInductsForLastHour(key: "USSStatistics",startTime:"02-18-2019 15:59") { duration measure condition totalInducts }}';
		fetch(graphQlURL, {
			method: 'POST',
			headers: {
			'Content-Type': 'application/json',
			'Accept': 'application/json',
			},
			body: JSON.stringify({
			query,
			variables: { key, startTime }
			})
		})
		.then(r => r.json())
		.then(data => { currentTemp = data.data.getInductsForLastHour.totalInducts;
						api.get(baseURL+'inductsfortheday/'+ localStorage.getItem("user_id") +this.props.sorterRoute)
		 .then(res => {
			    let label = res.data.inductsForTheDayList.map(list => list.currentDt);
			    let graphData = res.data.inductsForTheDayList.map(list => list.curr_value);
			    
			    this.setState({ data: res.data,
		        				label: label,
								currentValue: currentTemp,
		        				graphData: graphData,
								isLoading:false
					        });
		   }).catch(function (error) {
				console.log(error);
		  });
						return data; 
					})
		.catch((error) => {
			console.log(error);
		});
	}

	render() {
	
	const { isColorBlind } = this.props;
		
	var guageBGColor = json.container[0].leftLayout.components[0].options.guageBGColor
	var fontColor = json.container[0].rightLayout.components[0].componentTop.options.goalFontColor
	var graphBGColor = json.container[0].rightLayout.components[0].componentBottom.options.chartBGColor
	
	//Check For color blind and change the color
	if(isColorBlind) {
		guageBGColor = '#87871f'
		fontColor = '#1E90FF'
		graphBGColor = '#87871f'
	}
	
	if(this.state.isLoading){
			return <div>Loading...</div>;
		} else {
		const { recentOrders } = this.state;
		const percentage  = this.state.data.percentValue

		return (
				<RctCollapsibleCard
				colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
				heading={json.title}
				fullBlock
				>
					<div className="clearfix">
	                <div className="col-md-12 col-xl-12 col-sm-12 col-ls-12 float-left">
	                    <div className="d-flex">
	                        <div className="col-md-4 col-xl-4 col-sm-4 col-ls-4">
							<div className="circulararea">
	                        	<CircularProgressbar percentage={this.state.data.percentValue}
	                        						 text={`${this.state.data.percentValue}%`
													 }
	                        						 backgroundPadding={10}
	                        						 styles={{ path: { stroke: guageBGColor, strokeLinecap: 'butt'},
	                        							 	   text: { fill: '#121212', fontSize: '25px', textAnchor: "middle", dominantBaseline: "middle"},
	                        							 	   trail: { stroke: '#d7d7d7' },
	                        							 	   background: { fill: '#c3c3c3' }
															   
															   
	                        						 }}
	                        	/>
								</div>
	                        </div>
	                        <div className="col-md-8 col-xl-8 col-sm-8 col-ls-8">
	                            <div className="col-md-12 col-xl-12 col-sm-12 col-ls-12 text-center">
	                                <span className="counter-point">
										<strong>&nbsp; <NumberClass  number={this.state.currentValue} />  / &nbsp;
										<span style={{color: fontColor}}><NumberClass  number={json.container[0].rightLayout.components[0].componentTop.options.goalValue} /></span></strong>
	                                    {/*<IntlMessages id="widgets.weekly" /> / <IntlMessages id="widgets.monthly" />*/}
	                                </span>
	                            </div>
	                            <div className="col-md-12 col-xl-12 col-sm-12 col-ls-12">
								<div className="lastdays-text">{json.container[0].rightLayout.components[0].componentBottom.options.chartLabel}</div>
	                                <TinyAreaChart
	                                  
	                                    chartdata={this.state.graphData}
	                                    labels={this.state.label}
	                                    backgroundColor={hexToRgbA(ChartConfig.color.primary, 0.1)}
	                                    borderColor= {graphBGColor}
										lineTension="0"
	                                    height={130}
										fixedHeader={true}
	                                    gradient
	                                />
	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </RctCollapsibleCard>
		);
		}
	}
}

// map state to props
// Here we can fetch the value of isColorBlind as props
const mapStateToProps = ({ settings }) => {
	const { isColorBlind ,locale} = settings;
	//console.log("isColorBlind value inside mapstateToProps -- "+ isColorBlind);
	return { isColorBlind,locale };
};



export default withRouter(connect(mapStateToProps)(InductsForTheDay));
